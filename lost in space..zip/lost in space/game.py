import pygame
from sys import exit

pygame.init()

# Constants
SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 500
FPS = 60

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('Runner')
clock = pygame.time.Clock()

# Load images
ground_surface = pygame.image.load("Graphics/under_pressure_by_jestanda_dcl70td.png")
character = pygame.image.load("Characters/_com__anri_pixel_avatar_by_quartzstash_ddslbql.gif")
default_image_size = (SCREEN_WIDTH, SCREEN_HEIGHT)
default_character_size = (200, 450)

# Scale images
ground_surface = pygame.transform.scale(ground_surface, default_image_size)
character = pygame.transform.scale(character, default_character_size)

# Dialogue setup
dialogue_lines = [
    "Percy: sigh.........",
    "Percy: It's been 5 years since we embarked on this journey.",
    "Percy: I can't believe we're finally approaching Proxima B.",
    "Percy: I hope everything goes smoothly.",
    "Percy: Everyone, are you ready to uncover the truth of this planet?",
    "Dr. Red: But Commander Percy, are you sure we will find your", 
    "brother on this alien planet?",
    "Dr. Madrigal: Red is right, Commander.",
    "We are not sure what secrets this planet hides.",
    "Dr. Madrigal: We should turn back; we still have time.",
    "Percy: Guys, we embarked on this journey",
    "just to find the truth about this planet.",
    "Percy: Also to find the truth about your ex-commander", 
    " and my brother.",
    "Percy: Let's not back off now and make history together!"
]
current_line = 0

# Function to render text
def render_text(text, x, y):
    font = pygame.font.Font(None, 36)
    text_surface = font.render(text, True, BLACK)
    screen.blit(text_surface, (x, y))

# Game loop
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:  # Check for Enter key
                if current_line < len(dialogue_lines) - 1:
                    current_line += 1  # Move to the next line
                else:
                    current_line = 0  # Reset to the first line (optional)

    # Fill the screen with white
    screen.fill(WHITE)

    # Draw the background and character
    screen.blit(ground_surface, (0, 0))
    screen.blit(character, (100, 150))

    # Draw the dialogue box
    pygame.draw.rect(screen, BLUE, (50, SCREEN_HEIGHT - 100, SCREEN_WIDTH - 100, 80))
    render_text(dialogue_lines[current_line], 60, SCREEN_HEIGHT - 80)

    # Update the display
    pygame.display.update()

    # Cap the frame rate
    clock.tick(FPS)

# Quit Pygame
pygame.quit()