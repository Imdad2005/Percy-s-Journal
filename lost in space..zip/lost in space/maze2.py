import pygame
import sys
import time

# Constants
TILE_SIZE = 15
LEVEL_MAP = [
    'yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy',
    'y     y     y     y     y     y     y     y     y     y     y     y',
    'y  x  y  x  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y y',
    'y  x  x  0  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y y',
    'y  x  y  x  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y y',
    'y     y     y     y     y     y     y     y     y     y     y     y',
    'y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y y',
    'y  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  y y',
    'y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y y',
    'y     y     y     y     y     y     y     y     y     y     y     y',
    'y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y y',
    'y  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  y y',
    'y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y y',
    'y     y     y     y     y     y     y     y     y     y     y     y',
    'y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y y',
    'y  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  y y',
    'y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y y',
    'y     y     y     y     y     y     y     y     y     y     y     y',
    'y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y y',
    'y  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  y y',
    'y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y y',
    'y     y     y     y     y     y     y     y     y     y     y     y',
    'y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y y',
    'y  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  y y',
    'y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y y',
    'y     y     y     y     y     y     y     y     y     y     y     y',
    'y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y y',
    'y  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  x  y  y y',
    'y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y y',
    'y     y     y     y     y     y     y     y     y     y     y     y',
    'y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  y  yyyyy y  y y',
    'y                                                      P          y',
    'yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy',
]
SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 500
FPS = 60
GRAVITY = 0.5
PLAYER_JUMP_STRENGTH = -3
JUMP_DURATION = 1  # seconds
JUMP_COOLDOWN = 2  # seconds

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("MAZE")
clock = pygame.time.Clock()
font = pygame.font.Font(None, 36)

# Tile Class
class Tile(pygame.sprite.Sprite):
    def __init__(self, pos, size, tile_type):
        super().__init__()
        self.image = pygame.Surface((size, size))
        self.tile_type = tile_type
        if tile_type == 'x':
            self.image.fill('green')
        elif tile_type == 'y':
            self.image.fill('green')
        elif tile_type == '0':
            self.image.fill('blue')
        self.rect = self.image.get_rect(topleft=pos)

class Player(pygame.sprite.Sprite):
    def __init__(self, pos, size, *groups):
        super().__init__(*groups)
        self.image = pygame.Surface((size, size))
        self.image.fill('red')
        self.rect = self.image.get_rect(topleft=pos)
        self.velocity_y = 0
        self.on_ground = False
        self.jump_start_time = None
        self.can_jump = True

    def apply_gravity(self):
        self.velocity_y += GRAVITY
        self.rect.y += self.velocity_y

    def jump(self):
        current_time = time.time()
        if self.can_jump:
            if self.jump_start_time is None:
                self.jump_start_time = current_time
            if current_time - self.jump_start_time <= JUMP_DURATION:
                self.velocity_y = PLAYER_JUMP_STRENGTH
            else:
                self.can_jump = False
                self.jump_start_time = None

    def update(self, tiles):
        self.apply_gravity()
        self.on_ground = False

        # Check for vertical collisions with tiles
        for tile in tiles:
            if self.rect.colliderect(tile.rect):
                if tile.tile_type == 'y':
                    if self.velocity_y > 0:  # Falling
                        self.rect.bottom = tile.rect.top
                        self.velocity_y = 0
                        self.on_ground = True
                    elif self.velocity_y < 0:  # Jumping
                        self.rect.top = tile.rect.bottom
                        self.velocity_y = 0

        # Check for horizontal collisions with tiles
        for tile in tiles:
            if self.rect.colliderect(tile.rect):
                if tile.tile_type == 'y':
                    if self.rect.right > tile.rect.left and self.rect.left < tile.rect.right:
                        if self.rect.right > tile.rect.left and self.rect.left < tile.rect.centerx:
                            self.rect.right = tile.rect.left
                        elif self.rect.left < tile.rect.right and self.rect.right > tile.rect.centerx:
                            self.rect.left = tile.rect.right

        # Prevent player from leaving the maze boundaries
        if self.rect.left < TILE_SIZE:
            self.rect.left = TILE_SIZE
        if self.rect.right > (len(LEVEL_MAP[0]) - 1) * TILE_SIZE:
            self.rect.right = (len(LEVEL_MAP[0]) - 1) * TILE_SIZE
        if self.rect.top < TILE_SIZE:
            self.rect.top = TILE_SIZE
        if self.rect.bottom > (len(LEVEL_MAP) - 1) * TILE_SIZE:
            self.rect.bottom = (len(LEVEL_MAP) - 1) * TILE_SIZE

# Groups
tile_group = pygame.sprite.Group()
player_group = pygame.sprite.GroupSingle()

# Setup Tiles
for row_index, row in enumerate(LEVEL_MAP):
    for col_index, cell in enumerate(row):
        x, y = col_index * TILE_SIZE, row_index * TILE_SIZE
        if cell in 'xy0':
            tile = Tile((x, y), TILE_SIZE, cell)
            tile_group.add(tile)
        elif cell == 'P':
            player = Player((x, y), TILE_SIZE)
            player_group.add(player)

# Game Loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Update Player
    player_group.update(tile_group)

    # Player Movement (WASD)
    keys = pygame.key.get_pressed()
    if keys[pygame.K_a]:  # Move left
        player_group.sprite.rect.x -= 5
    if keys[pygame.K_d]:  # Move right
        player_group.sprite.rect.x += 5
    if keys[pygame.K_w]:  # Jump
        player_group.sprite.jump()

    # Draw
    screen.fill('black')
    tile_group.draw(screen)
    player_group.draw(screen)

    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()
sys.exit()
