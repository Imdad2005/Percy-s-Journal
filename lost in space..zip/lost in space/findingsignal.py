import pygame
import random
import sys
import time

pygame.init()

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Find Signal")

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
YELLOW = (255, 255, 0)

font = pygame.font.Font(None, 36)

TIMER_LIMIT = 60
GRID_SIZE = 10
CELL_SIZE = 50
GRID_START_X = (WIDTH - GRID_SIZE * CELL_SIZE) // 2
GRID_START_Y = 100

grid_numbers = [[random.randint(10, 99) for _ in range(GRID_SIZE)] for _ in range(GRID_SIZE)]

target_row = random.randint(0, GRID_SIZE - 1)
start_col = random.randint(0, GRID_SIZE - 3)
target_signal = grid_numbers[target_row][start_col:start_col + 3]

start_ticks = pygame.time.get_ticks()
time_remaining = TIMER_LIMIT

selected_row, selected_start_col = 0, 0
game_over = False
win = False
blink_start_time = None
blink_state = False

running = True
while running:
    screen.fill(BLACK)

    if not game_over:
        current_ticks = pygame.time.get_ticks()
        time_remaining = max(0, TIMER_LIMIT - (current_ticks - start_ticks) // 1000)

    if time_remaining == 0 and not game_over:
        game_over = True

    if blink_start_time:
        elapsed_time = time.time() - blink_start_time
        if elapsed_time >= 2:
            blink_start_time = None
        else:
            blink_state = int(elapsed_time * 4) % 2 == 0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and not game_over and not blink_start_time:
            if event.key == pygame.K_w and selected_row > 0:
                selected_row -= 1
            if event.key == pygame.K_s and selected_row < GRID_SIZE - 1:
                selected_row += 1
            if event.key == pygame.K_a and selected_start_col > 0:
                selected_start_col -= 1
            if event.key == pygame.K_d and selected_start_col < GRID_SIZE - 3:
                selected_start_col += 1
            if event.key == pygame.K_RETURN:
                if grid_numbers[selected_row][selected_start_col:selected_start_col + 3] == target_signal:
                    win = True
                    game_over = True
                else:
                    blink_start_time = time.time()
                    time_remaining = max(0, time_remaining - 5)

    for row in range(GRID_SIZE):
        for col in range(GRID_SIZE):
            cell_x = GRID_START_X + col * CELL_SIZE
            cell_y = GRID_START_Y + row * CELL_SIZE
            if row == selected_row and selected_start_col <= col < selected_start_col + 3:
                if blink_start_time:
                    cell_color = RED if blink_state else WHITE
                else:
                    cell_color = YELLOW
            else:
                cell_color = WHITE
            pygame.draw.rect(screen, cell_color, (cell_x, cell_y, CELL_SIZE, CELL_SIZE), 2)
            number_text = font.render(str(grid_numbers[row][col]), True, WHITE)
            screen.blit(number_text, (cell_x + CELL_SIZE // 4, cell_y + CELL_SIZE // 4))

    target_text = font.render(f"Target Signals: {' '.join(map(str, target_signal))}", True, WHITE)
    screen.blit(target_text, (WIDTH // 2 - target_text.get_width() // 2, 20))
    timer_text = font.render(
        f"Time Left: {time_remaining}s", True, RED if time_remaining <= 5 else WHITE
    )
    screen.blit(timer_text, (WIDTH // 2 - timer_text.get_width() // 2, 50))

    if game_over:
        result_text = font.render("You Win!" if win else "You Lose!", True, GREEN if win else RED)
        screen.blit(result_text, (WIDTH // 2 - result_text.get_width() // 2, HEIGHT // 2))

    pygame.display.flip()

pygame.quit()
sys.exit()
