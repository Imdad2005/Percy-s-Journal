import pygame
import sys

# Initialize Pygame
pygame.init()
pygame.mixer.init()

# Constants
SCREEN_WIDTH, SCREEN_HEIGHT = 1000, 500
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)
FPS = 60

# Setup
pygame.display.set_caption('Stellar Odyssey')
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()
font_large = pygame.font.SysFont('timesnewroman', 80)
font_small = pygame.font.SysFont('timesnewroman', 40)

# Load Resources
try:
    background_image = pygame.image.load('Graphics/main3.jpg')
    background_image = pygame.transform.scale(background_image, (SCREEN_WIDTH, SCREEN_HEIGHT))
    platform_surface = pygame.image.load('Graphics/platform.png').convert()
    rover = pygame.image.load('Characters/rover.PNG').convert_alpha()
    percy = pygame.image.load('Characters/_com__anri_pixel_avatar_by_quartzstash_ddslbql.gif').convert_alpha()
    percy = pygame.transform.scale(percy, (150, 150))
except FileNotFoundError as e:
    print(f"Error: Missing file {e}")
    sys.exit()

# Utility Functions
def draw_text_centered(surface, text, y, font_size=36, color=WHITE):
    font = pygame.font.Font(None, font_size)
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect(center=(SCREEN_WIDTH // 2, y))
    surface.blit(text_surface, text_rect)

def render_dialogue(dialogue_lines):
    current_line = 0
    while current_line < len(dialogue_lines):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                current_line += 1

        screen.fill(BLACK)
        draw_text_centered(screen, dialogue_lines[current_line], SCREEN_HEIGHT // 2)
        pygame.display.update()
        clock.tick(FPS)

# Screens
def main_menu():
    while True:
        screen.blit(background_image, (0, 0))  # Display the background image
        draw_text_centered(screen, "Stellar Odyssey", 100, 80, WHITE)
        draw_text_centered(screen, "Press Enter to Start", 300, 40, WHITE)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                intro_dialogue()

        pygame.display.update()
        clock.tick(FPS)

def intro_dialogue():
    intro_lines = [
        "Percy: sigh.........",
        "Percy: It's been 5 years since we embarked on this journey.",
        "Percy: I can't believe we're finally approaching Proxima B.",
        "Dr. Red: Are you sure we will find your brother on this alien planet?",
        "Dr. Madrigal: Red is right, Commander.",
        "Percy: Guys, we embarked on this journey to find the truth about Proxima B.",
        "Percy: And to find my brother. Let's not back off now!",
    ]
    render_dialogue(intro_lines)
    crash_scene()

def crash_scene():
    crash_lines = [
        "As the crew approached the planet's orbit,",
        "an asteroid struck their ship, damaging the engine.",
        "Percy: Everyone, brace for impact! We're crashing into Proxima B!",
        "After the crash, Percy finds herself separated from the crew.",
    ]
    render_dialogue(crash_lines)
    gameplay()

def gameplay():
    rover_pos = 600
    rover_stop_position = 400
    rover_speed = 2

    dialogue_active = True
    dialogue_lines = [
        "Percy's suit starts beeping.",
        "Percy: 'What now?... Oxygen levels critical?!'",
        "Percy: 'Damn it! What's the atmospheric composition?'",
        "After analyzing: 'I can survive but not for long.'",
        "Percy turns off her suit's oxygen module and breathes Proxima B's air.",
        "Percy: 'Hmm... That's not half as bad as I thought.'",
    ]
    current_line = 0

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN and dialogue_active:
                if event.key == pygame.K_RETURN:
                    current_line += 1
                    if current_line >= len(dialogue_lines):
                        dialogue_active = False

        # Draw the background (platform)
        screen.blit(platform_surface, (0, 0))  # This is your main environment

        # Draw Percy (the character)
        screen.blit(percy, (200, 130))  # Percy should appear on the screen

        # Dialogue box with text
        if dialogue_active and current_line < len(dialogue_lines):
            pygame.draw.rect(screen, BLACK, (50, 350, 900, 100))
            draw_text_centered(screen, dialogue_lines[current_line], 380, 36, WHITE)

        # Rover movement after dialogue ends
        if not dialogue_active and rover_pos > rover_stop_position:
            rover_pos -= rover_speed

        # Draw rover
        screen.blit(rover, (rover_pos, 240))

        pygame.display.update()
        clock.tick(FPS)

# Main
main_menu()
