import pygame
import random

# Initialize Pygame
pygame.init()

# Screen dimensions
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Guess the Number Puzzle")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

# Fonts
font = pygame.font.Font(None, 48)
small_font = pygame.font.Font(None, 36)

# Random number to guess
number_to_guess = random.randint(1, 100)

# Game variables
guess = ""
feedback = "Guess a number between 1 and 100!"
attempts = 0
game_over = False

# Main game loop
running = True
while running:
    screen.fill(WHITE)  # Clear the screen

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN and not game_over:
            if event.key == pygame.K_RETURN:  # Check if Enter is pressed
                if guess.isdigit():  # Ensure the input is a number
                    attempts += 1
                    guess_number = int(guess)
                    if guess_number < number_to_guess:
                        feedback = "Too Low! Try Again."
                    elif guess_number > number_to_guess:
                        feedback = "Too High! Try Again."
                    else:
                        feedback = f"Correct! You guessed it in {attempts} attempts!"
                        game_over = True
                else:
                    feedback = "Please enter a valid number!"
                guess = ""  # Reset input

            elif event.key == pygame.K_BACKSPACE:  # Remove the last character
                guess = guess[:-1]
            else:  # Add typed character to the guess
                if event.unicode.isdigit():
                    guess += event.unicode

    # Display feedback and input
    feedback_text = font.render(feedback, True, BLACK)
    guess_text = font.render(f"Your Guess: {guess}", True, GREEN if not game_over else RED)

    # Instructions
    instruction_text = small_font.render("Type a number and press Enter. Use Backspace to delete.", True, BLACK)

    # Render text on screen
    screen.blit(feedback_text, (50, 150))
    screen.blit(guess_text, (50, 250))
    screen.blit(instruction_text, (50, 350))

    # Update display
    pygame.display.flip()

pygame.quit()