import pygame
import sys

# Initialize Pygame
pygame.init()
pygame.mixer.init()

# Constants
SCREEN_WIDTH, SCREEN_HEIGHT = 1000, 500
BG_COLOR = (0, 0, 0)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
FPS = 60

# Setup
pygame.display.set_caption('Game Base')
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()
font_large = pygame.font.SysFont('timesnewroman', 80)
font_small = pygame.font.SysFont('timesnewroman', 40)

# Load Resources
try:
    background_image = pygame.image.load('Graphics/main3.jpg')
except FileNotFoundError:
    print("Error: Background image not found.")
    sys.exit()

try:
    pygame.mixer.music.load('Audio/light_through_a_pale_window.flac')
    pygame.mixer.music.play(-1)
    pygame.mixer.music.set_volume(0.5)
except FileNotFoundError:
    print("Error: Background music not found.")
    sys.exit()

# Dialogue setup
dialogue_lines = [
    "Percy: sigh.........",
    "Percy: It's been 5 years since we embarked on this journey.",
    "Percy: I can't believe we're finally approaching Proxima B.",
    "Percy: I hope everything goes smoothly.",
    "Percy: Everyone, are you ready to uncover the truth of this planet?",
    "Dr. Red: But Commander Percy, are you sure we will find your", 
    "brother on this alien planet?",
    "Dr. Madrigal: Red is right, Commander.",
    "We are not sure what secrets this planet hides.",
    "Dr. Madrigal: We should turn back; we still have time.",
    "Percy: Guys, we embarked on this journey",
    "just to find the truth about this planet.",
    "Percy: Also to find the truth about your ex-commander", 
    " and my brother.",
    "Percy: Let's not back off now and make history together!"
]
current_line = 0

def render_text(text, x, y):
    font = pygame.font.Font(None, 36)
    text_surface = font.render(text, True, BLACK)
    screen.blit(text_surface, (x, y))

# Utility Functions
def draw_text(text, font, color, surface, x, y, shadow=None):
    if shadow:
        shadow_x, shadow_y = x + shadow[0], y + shadow[1]
        shadow_surface = font.render(text, True, shadow[2])
        surface.blit(shadow_surface, (shadow_x, shadow_y))
    text_surface = font.render(text, True, color)
    surface.blit(text_surface, (x, y))

# Screens
def main_menu():
    while True:
        screen.blit(background_image, (-120, -90))

        # Title
        draw_text("Stellar Odyssey", font_large, WHITE, screen, 280, 50, shadow=(4, 4, (50, 50, 50)))

        # Buttons
        mx, my = pygame.mouse.get_pos()
        button_start = pygame.Rect(400, 300, 200, 50)
        button_options = pygame.Rect(400, 400, 200, 50)

        pygame.draw.rect(screen, (150, 0, 0), button_start, border_radius=5)
        pygame.draw.rect(screen, (150, 0, 0), button_options, border_radius=5)
        draw_text("Start Game", font_small, WHITE, screen, 420, 310)
        draw_text("Options", font_small, WHITE, screen, 450, 410)

        # Hover/Click Logic
        click = False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                click = True

        if button_start.collidepoint((mx, my)) and click:
            dialogue()
        if button_options.collidepoint((mx, my)) and click:
            options()

        pygame.display.update()
        clock.tick(60)

def dialogue():
    global current_line
    current_line = 0  # Reset dialogue to the first line
    ground_surface = pygame.image.load("Graphics/under_pressure_by_jestanda_dcl70td.png")
    character = pygame.image.load("Characters/_com__anri_pixel_avatar_by_quartzstash_ddslbql.gif")

    # Scale images
    ground_surface = pygame.transform.scale(ground_surface, (SCREEN_WIDTH, SCREEN_HEIGHT))
    character = pygame.transform.scale(character, (200, 450))

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:  # Check for Enter key
                    if current_line < len(dialogue_lines) - 1:
                        current_line += 1  # Move to the next line
                    else:
                        return  # End dialogue

        # Fill the screen with white
        screen.fill(WHITE)

        # Draw the background and character
        screen.blit(ground_surface, (0, 0))
        screen.blit(character, (100, 150))

        # Draw the dialogue box
        pygame.draw.rect(screen, BLUE, (50, SCREEN_HEIGHT - 100, SCREEN_WIDTH - 100, 80))
        render_text(dialogue_lines[current_line], 60, SCREEN_HEIGHT - 80)

        # Update the display
        pygame.display.update()
        clock.tick(FPS)

def options():
    while True:
        screen.fill(BG_COLOR)
        draw_text("Options", font_large, WHITE, screen, 20, 20)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return
        pygame.display.update()
        clock.tick(FPS)

# Main
main_menu()
