#!/usr/bin/python3
import sys
import pygame
from sys import exit

pygame.init()

# Screen setup
SCREEN_WIDTH, SCREEN_HEIGHT = 1000, 500
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('Runner')
clock = pygame.time.Clock()

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# Music
try:
    pygame.mixer.music.load('Audio/light_through_a_pale_window.flac')
    pygame.mixer.music.play(-1)
    pygame.mixer.music.set_volume(0.5)
except FileNotFoundError:
    print("Error: Background music not found.")
    sys.exit()

# Dialogue setup
dialogue_lines = [
    "Percy's suit starts beeping",
    "Percy: 'What now?....'",
    "Oxygen levels critical",
    "Percy: 'Damn it!'",
    "Percy: What's the atmospheric composition?",
    "Checks the data within",
    "With such concentrated levels of oxygen,",
    "I will not be able to function efficiently...",
    "but I should be able to survive long enough",
    "for the crew to find me.",
    "Percy turns off her suit's oxygen module.",
    "Percy breathes in the air of Proxima B.",
    "Hmm.... That's not half as bad as I thought.",
    "(Excessive oxygen has already taken effect.)",
]
current_line = 0
dialogue_active = True

# Utility function to render text
def draw_text(text, x, y, font_size=36, color=WHITE, shadow=None):
    font = pygame.font.Font(None, font_size)
    if shadow:
        shadow_x, shadow_y = x + shadow[0], y + shadow[1]
        shadow_surface = font.render(text, True, shadow[2])
        screen.blit(shadow_surface, (shadow_x, shadow_y))
    text_surface = font.render(text, True, color)
    screen.blit(text_surface, (x, y))

# Load graphics
surface = pygame.image.load('Graphics/platform.png').convert()
rover = pygame.image.load('Characters/rover.PNG').convert_alpha()
percy = pygame.image.load('Characters/_com__anri_pixel_avatar_by_quartzstash_ddslbql.gif').convert_alpha()

# Scale Percy image
percy = pygame.transform.scale(percy, (150, 150))
percy_rect = percy.get_rect(topleft=(200, 130))

# Rover setup
rover_pos = 600
rover_stop_position = 400

# Function to handle dialogue
def run_dialogue():
    global current_line, dialogue_active
    while dialogue_active:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:  # Check for Enter key
                    current_line += 1  # Move to the next line
                    if current_line >= len(dialogue_lines):
                        dialogue_active = False  # End dialogue

        # Draw background and Percy
        screen.blit(surface, (-120, -90))
        screen.blit(percy, percy_rect)

        # Draw dialogue box and text
        pygame.draw.rect(screen, BLACK, (50, 350, 900, 100))  # Dialogue box
        if current_line < len(dialogue_lines):
            draw_text(dialogue_lines[current_line], 60, 370)

        pygame.display.update()
        clock.tick(60)

# Main game loop
run_dialogue()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()

    # Draw background and Percy
    screen.blit(surface, (-120, -90))
    screen.blit(percy, percy_rect)

    # Move the rover after the dialogue ends
    if not dialogue_active and rover_pos > rover_stop_position:
        rover_pos -= 1  # Decrease the rover's position

    # Draw the rover
    screen.blit(rover, (rover_pos, 240))

    pygame.display.update()
    clock.tick(60)
