import pygame
from sys import exit

pygame.init()

# Screen setup
screen = pygame.display.set_mode((1000, 500))
pygame.display.set_caption('Runner')

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

# Dialogue lines
dialogue_lines = [
    "As soon as the crew approached near the planet's orbit,",
    "due to the unknown environment they were dealing with,",
    "the crew's spaceship was hit by an asteroid,",
    "which damaged the ship's engine.",
    "Percy: Everyone, hands up! We're about to crash into Proxima B!",
    "Unfortunately, the crew got separated from each other.",
    "Now Percy has to find her lost crewmates.",
]
current_line = 0

# Font setup
font = pygame.font.Font(None, 36)

# Function to render centered text
def render_text_centered(surface, text, y, color=WHITE):
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect(center=(screen.get_width() // 2, y))
    surface.blit(text_surface, text_rect)

running = True
while running:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:  # Check for Enter key
                if current_line < len(dialogue_lines) - 1:
                    current_line += 1  # Move to the next line
                else:
                    running = False  # Exit dialogue loop

    # Draw background
    screen.fill(BLACK)

    # Render the current line of dialogue in the center
    render_text_centered(screen, dialogue_lines[current_line], screen.get_height() // 2, WHITE)

    # Update display
    pygame.display.update()
